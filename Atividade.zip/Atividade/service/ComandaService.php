<?php
require_once(__DIR__ . "/../model/Comanda.php");
session_start();

class ComandaService {

    public function criarComanda(int $mesa): string {
        if (!isset($_SESSION['comandas'])) {
            $_SESSION['comandas'] = [];
        }

        if (isset($_SESSION['comandas'][$mesa])) {
            return "Erro: comanda da mesa $mesa já existe!";
        }

        $_SESSION['comandas'][$mesa] = new Comanda($mesa);
        return "Comanda da mesa $mesa criada com sucesso!";
    }

    public function adicionarItem(int $mesa, Produto $produto): string {
        if (!isset($_SESSION['comandas'][$mesa])) {
            return "Erro: comanda não encontrada!";
        }

        $_SESSION['comandas'][$mesa]->adicionarItem($produto);
        return "Produto '{$produto->getNome()}' adicionado à mesa $mesa!";
    }

    public function listar(): array {
        return $_SESSION['comandas'] ?? [];
    }

    public function encerrar(int $mesa): string {
        if (!isset($_SESSION['comandas'][$mesa])) {
            return "Erro: comanda não existe!";
        }

        unset($_SESSION['comandas'][$mesa]);
        return "Comanda da mesa $mesa encerrada!";
    }

    public function limparSessao(): void {
        session_destroy();
    }
}
