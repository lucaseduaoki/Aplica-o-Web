<h1>Gerenciar Comandas</h1>

<a href="view/form.php"><button>Criar Comanda</button></a>
<a href="view/alterar.php"><button>Adicionar Item</button></a>
<a href="view/listar.php"><button>Listar Comandas</button></a>
<a href="view/excluir.php"><button>Encerrar Comanda</button></a>
