<?php
session_start();
require_once(__DIR__ . "/../model/Comanda.php");
require_once(__DIR__ . "/../model/Produto.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $mesa = intval($_POST['mesa']);
    $produtoId = intval($_POST['produto_id']);

    // Cardápio fixo
    $cardapio = [
        1 => new Produto(1, "Coxinha", 6.00),
        2 => new Produto(2, "Pastel", 8.00),
        3 => new Produto(3, "Refrigerante", 7.00),
        4 => new Produto(4, "Cerveja", 10.00),
        5 => new Produto(5, "Batata Frita", 15.00)
    ];

    // Inicia o array de comandas na sessão
    if (!isset($_SESSION['comandas'])) {
        $_SESSION['comandas'] = [];
    }

    // Verifica se a comanda da mesa já existe
    if (!isset($_SESSION['comandas'][$mesa])) {
        $_SESSION['comandas'][$mesa] = new Comanda($mesa);
        $mensagem = "Comanda da mesa $mesa criada com sucesso!<br>";
    } else {
        $mensagem = "Comanda da mesa $mesa atualizada!<br>";
    }

    // Adiciona o produto selecionado
    if (isset($cardapio[$produtoId])) {
        $produto = $cardapio[$produtoId];
        $_SESSION['comandas'][$mesa]->adicionarItem($produto);
        $mensagem .= "Produto <strong>{$produto->getNome()}</strong> adicionado com sucesso!";
    } else {
        $mensagem .= "<span style='color:red;'>Produto inválido!</span>";
    }

    echo "<p>$mensagem</p>";
}
?>

<h2>Criar ou Atualizar Comanda</h2>

<form method="POST">
    <label for="mesa">Mesa:</label>
    <input type="number" id="mesa" name="mesa" required><br><br>

    <label for="produto_id">Produto:</label>
    <select name="produto_id" id="produto_id" required>
        <option value="">Selecione um produto</option>
        <option value="1">Coxinha - R$6,00</option>
        <option value="2">Pastel - R$8,00</option>
        <option value="3">Refrigerante - R$7,00</option>
        <option value="4">Cerveja - R$10,00</option>
        <option value="5">Batata Frita - R$15,00</option>
    </select><br><br>

    <label for="qntd">Quantidade:</label>
    <input type="number" id="quantidade" name="quantidade" require><br><br>

    <button type="submit">Salvar Comanda</button>
</form>

<br>
<a href="listar.php"><button type="button">Ver Comandas</button></a>
