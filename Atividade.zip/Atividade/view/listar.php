<?php
require_once(__DIR__ . "/../controller/ComandaController.php");
$controller = new ComandaController();
$comandas = $controller->listar();
?>

<h2>Comandas Abertas</h2>

<?php if (empty($comandas)): ?>
    <p>Nenhuma comanda aberta.</p>
<?php else: ?>
    <?php foreach ($comandas as $mesa => $comanda): ?>
        <h3>Mesa <?= $mesa ?></h3>
        <ul>
            <?php foreach ($comanda->getItens() as $item): ?>
                <li><?= $item->getNome() ?> - R$<?= number_format($item->getPreco(), 2, ',', '.') ?></li>
            <?php endforeach; ?>
        </ul>
    <?php endforeach; ?>
<?php endif; ?>
