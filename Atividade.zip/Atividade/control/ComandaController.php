<?php
require_once(__DIR__ . "/../service/ComandaService.php");

class ComandaController {
    private ComandaService $service;

    public function __construct() {
        $this->service = new ComandaService();
    }

    public function criar($mesa) {
        return $this->service->criarComanda($mesa);
    }

    public function adicionarItem($mesa, $id, $nome, $preco) {
        $produto = new Produto($id, $nome, $preco);
        return $this->service->adicionarItem($mesa, $produto);
    }

    public function listar() {
        return $this->service->listar();
    }

    public function encerrar($mesa) {
        return $this->service->encerrar($mesa);
    }
}
