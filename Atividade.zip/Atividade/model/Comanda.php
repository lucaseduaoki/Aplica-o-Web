<?php

require_once(__DIR__ . "/Produto.php");

class Comanda{

    private ?int $mesa;
    private array $itens = [];


    public function __construct(int $mesa){
        $this->mesa = $mesa;
        $this->itens = [];
    }

    /**
     * Get the value of mesa
     */
    public function getMesa(): ?int
    {
        return $this->mesa;
    }

    /**
     * Set the value of mesa
     */
    public function setMesa(?int $mesa): self
    {
        $this->mesa = $mesa;

        return $this;
    }

    /**
     * Get the value of itens
     */
    public function getItens(): array
    {
        return $this->itens;
    }

    /**
     * Set the value of itens
     */
    public function setItens(array $itens): self
    {
        $this->itens = $itens;

        return $this;
    }
}